
const express = require('express');
const router = express.Router();

const userController = require('../controllers/userController');

router.get('/', userController.getAllUsers);
router.post('/', userController.createUser);
router.put('/:id', userController.updateUser); // Rota para atualizar um usuário
router.delete('/:id', userController.deleteUser); // Rota para excluir um usuário

module.exports = router;

'''Agora, as rotas para atualizar e excluir usuários foram adicionadas ao arquivo de roteamento. Essas rotas utilizarão 
as funções `updateUser` e `deleteUser` do `userController` respectivamente.'''